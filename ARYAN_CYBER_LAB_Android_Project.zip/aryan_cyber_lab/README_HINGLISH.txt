ARYAN CYBER LAB — Android project source

This is a native Android starter project (not a compiled APK yet).
It includes:
- Phone number format/country-prefix clues (not live tracking)
- Your own GPS location -> opens Google Maps after Android permission
- Public IP approximate geolocation lookup
- Basic URL analyzer

Build APK:
1. Upload this ZIP to a private GitHub repository.
2. Open it in Android Studio or use the included Gradle project.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated app-debug.apk on your Android phone.

Important:
- The app does not secretly track anyone.
- A person's live GPS requires their explicit permission.
- Public IP location is approximate.
