package com.aryan.cyberlab

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.content.Intent
import android.location.LocationManager
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 15, 25)
    private val panel = Color.rgb(20, 29, 43)
    private val green = Color.rgb(70, 230, 160)
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun shell(title: String, subtitle: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val heading = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(green)
            typeface = Typeface.DEFAULT_BOLD
        }
        body.addView(heading)
        body.addView(TextView(this).apply {
            text = subtitle; textSize = 13f; setTextColor(Color.LTGRAY)
            setPadding(0, 6, 0, 22)
        })
    }

    private fun card(title: String, desc: String, action: () -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = GradientDrawable().apply {
                setColor(panel); cornerRadius = 18f
                setStroke(1, Color.rgb(42, 66, 78))
            }
        }
        box.addView(TextView(this).apply {
            text = title; textSize = 17f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply {
            text = desc; textSize = 12f; setTextColor(Color.LTGRAY); setPadding(0, 5, 0, 0)
        })
        box.setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = 12
        body.addView(box, lp)
    }

    private fun field(hint: String): EditText {
        return EditText(this).apply {
            this.hint = hint; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            textSize = 15f
            background = GradientDrawable().apply {
                setColor(panel); cornerRadius = 12f; setStroke(1, Color.DKGRAY)
            }
            setPadding(14, 12, 14, 12)
        }.also {
            body.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
        }
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label; isAllCaps = false; setTextColor(bg)
            background = GradientDrawable().apply { setColor(green); cornerRadius = 14f }
        }
        b.setOnClickListener { action() }
        body.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 12 })
    }

    private fun result(message: String) {
        body.addView(TextView(this).apply {
            text = message; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(14, 14, 14, 14)
            background = GradientDrawable().apply { setColor(panel); cornerRadius = 12f }
        })
    }

    private fun backButton() = button("← Dashboard") { showHome() }

    private fun showHome() {
        shell("ARYAN CYBER LAB", "PERSONAL CYBERSECURITY TOOLKIT  •  ANDROID")
        result("Private-use toolkit. Location features only access your own device location or a location another person explicitly shares.")
        card("01  PHONE INTELLIGENCE", "Number format and country-code clues. No private GPS tracking.", ::phoneTool)
        card("02  MY GPS LOCATION", "Open your own device location in Google Maps after permission.", ::myLocation)
        card("03  IP INTELLIGENCE", "Look up approximate public IP region, ISP and network details.", ::ipTool)
        card("04  LINK ANALYZER", "Inspect URL format and basic HTTPS/security indicators.", ::linkTool)
        card("05  SAFETY NOTES", "Learn what phone numbers and IP addresses can—and cannot—reveal.", ::safety)
        result("Version 1.0 • More authorized security-testing modules can be added later.")
    }

    private fun phoneTool() {
        shell("PHONE INTELLIGENCE", "Basic number clues only — not a person's live location.")
        val input = field("Enter number with country code, e.g. +91...")
        button("ANALYZE NUMBER") {
            val n = input.text.toString().trim()
            val digits = n.filter { it.isDigit() }
            val country = when {
                n.startsWith("+91") -> "India (+91)"
                n.startsWith("+1") -> "North America (+1)"
                n.startsWith("+44") -> "United Kingdom (+44)"
                n.startsWith("+971") -> "UAE (+971)"
                n.startsWith("+61") -> "Australia (+61)"
                n.startsWith("+") -> "International number; country prefix needs a dedicated numbering database"
                else -> "No country code entered"
            }
            val validShape = digits.length in 7..15
            result("Number: ${if (n.isBlank()) "Not entered" else n}\nDigit count: ${digits.length}\nCountry clue: $country\nFormat check: ${if (validShape) "Plausible length" else "Check the number"}\n\nThis cannot reveal exact address, live GPS, or current area. Number portability can also make operator/circle guesses unreliable.")
        }
        backButton()
    }

    private fun myLocation() {
        shell("MY GPS LOCATION", "This reads location from this phone only, after your permission.")
        result("Tap the button and allow Android location permission. Your coordinates are not sent to a server by this app.")
        button("OPEN MY LOCATION IN MAPS") {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 44)
                Toast.makeText(this, "Allow location, then tap again.", Toast.LENGTH_LONG).show()
            } else {
                try {
                    val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                    val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                        ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    if (loc != null) {
                        val uri = Uri.parse("geo:${loc.latitude},${loc.longitude}?q=${loc.latitude},${loc.longitude}(My%20Location)")
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } else {
                        result("No recent location fix. Turn on Location/GPS, wait a moment, then try again.")
                    }
                } catch (e: Exception) { result("Could not read location: ${e.message}") }
            }
        }
        backButton()
    }

    private fun ipTool() {
        shell("IP INTELLIGENCE", "Public IP lookup. Results are approximate and depend on the network provider.")
        val output = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f }
        body.addView(output)
        button("LOOK UP MY PUBLIC IP") {
            output.text = "Checking…"
            thread {
                val text = try {
                    val c = URL("https://ipapi.co/json/").openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val data = c.inputStream.bufferedReader().use { it.readText() }
                    val j = JSONObject(data)
                    "IP: ${j.optString("ip")}\nCity: ${j.optString("city")}\nRegion: ${j.optString("region")}\nCountry: ${j.optString("country_name")}\nISP/Org: ${j.optString("org")}\nASN: ${j.optString("asn")}\n\nApproximate network location only — not a person's exact GPS."
                } catch (e: Exception) { "Lookup failed. Check internet connection and try again." }
                runOnUiThread { output.text = text }
            }
        }
        backButton()
    }

    private fun linkTool() {
        shell("LINK ANALYZER", "Basic local checks. Do not open suspicious links.")
        val input = field("Paste full URL (https://...)")
        button("ANALYZE URL") {
            val raw = input.text.toString().trim()
            try {
                val uri = Uri.parse(if (raw.startsWith("http")) raw else "https://$raw")
                val host = uri.host ?: "Unknown host"
                val scheme = uri.scheme ?: "Unknown"
                val hasUserInfo = !uri.userInfo.isNullOrBlank()
                result("Host: $host\nProtocol: $scheme\nHTTPS: ${if (scheme.equals("https", true)) "Yes" else "No"}\nEmbedded username/password: ${if (hasUserInfo) "YES — suspicious" else "No"}\n\nThis is only a basic URL check. It cannot guarantee a site is safe.")
            } catch (e: Exception) { result("Could not parse this URL. Check the text and try again.") }
        }
        backButton()
    }

    private fun safety() {
        shell("SAFETY & LIMITATIONS", "Use this toolkit only on your own device, network, or systems you have permission to test.")
        result("• A phone number alone does not expose someone's live GPS or home address.\n\n• IP geolocation usually points to an approximate provider/network region, not a person's exact location.\n\n• Live GPS sharing requires the other person's clear consent and Android/browser permission.\n\n• Never use scan tools against networks or websites without authorization.")
        backButton()
    }
}
